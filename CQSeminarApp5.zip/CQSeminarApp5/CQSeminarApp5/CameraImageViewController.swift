//
//  CameraImageViewController.swift
//  CQSeminarApp5
//
//  Created by Minori Awamura on 2016/05/06.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class CameraImageViewController: UIViewController {

    @IBOutlet weak var cameraImage: UIImageView!
    
    var imageFromPin: UIImage?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // 渡された写真を表示
        cameraImage.image = imageFromPin
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
