//
//  GrayScreenViewController.swift
//  CQSeminarApp1
//
//  Created by Minori Awamura on 2016/04/27.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class GrayScreenViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // セグエの戻り
    @IBAction func returnUnwindSegue (segue: UIStoryboardSegue) {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
