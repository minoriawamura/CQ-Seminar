//
//  ViewController.swift
//  CQSeminarApp3
//
//  Created by Minori Awamura on 2016/05/02.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var titleField: UITextField!
    
    @IBOutlet weak var pickedDate: UIDatePicker!

    
    var dailyTitle = ""
    var setDate = NSDate()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func changeDate(sender: UIDatePicker) {
        setDate = sender.date
    }

    @IBAction func nextButton(sender: UIButton) {
        
        dailyTitle = titleField.text!
        setDate = pickedDate.date
        
        if dailyTitle == "" {
            let alert = UIAlertController(title: "タイトル", message: "タイトルがありません", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            
            self.presentViewController(alert, animated: true, completion: nil)
            
        } else {
            
            performSegueWithIdentifier("segueToDetail", sender: self)
        }
        
    }
    
    @IBAction func tapScreen(sender: UITapGestureRecognizer) {
        if titleField.editing {
            dailyTitle = titleField.text!
            titleField.endEditing(true)
        }
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        let destVC = segue.destinationViewController as! DetailViewController
        
        destVC.titletext = dailyTitle
        destVC.setDate = setDate

        
    }
    
    
}

