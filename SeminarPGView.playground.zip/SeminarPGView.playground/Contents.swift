//: Playground - noun: a place where people can play

import UIKit
import XCPlayground

// テキストラベルの定義
let labelSample = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: 50))
labelSample.backgroundColor = UIColor.cyanColor()
labelSample.text = "CQセミナー"
labelSample.textAlignment = NSTextAlignment.Center

// テキストフィールドの定義
let textFieldSample = UITextField(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
textFieldSample.backgroundColor = UIColor.whiteColor()
textFieldSample.borderStyle = UITextBorderStyle.Line


// UI部品を動作させて見る

// UIViewの定義
class PGView: UIView {
    
    let myField = UITextField()
    
    // イニシャライザ
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.lightGrayColor()
    }
    
    // テキストラベル作成
    func makeLabel(frame: CGRect, text: String) -> UILabel {
        let label = UILabel(frame: frame)
        label.text = text
        label.backgroundColor = UIColor.whiteColor()
        label.textAlignment = NSTextAlignment.Right
        
        return label
    }
    
    // テキストフィールド作成
    func makeTextFieldd(frame: CGRect, placeholder: String) -> UITextField {
        let textField = UITextField(frame: frame)
        textField.backgroundColor = UIColor.whiteColor()
        textField.placeholder = placeholder
        
        return textField
    }
    
    // ボタンの作成
    func makeButton(frame: CGRect, title: String, tag: Int) -> UIButton {
        let button = UIButton(type: .System)
        button.frame = frame
        button.tag = tag
        button.setTitle(title, forState: UIControlState.Normal)
        button.backgroundColor = UIColor.whiteColor()
        button.addTarget(self, action: #selector(PGView.onTapButton(_:)), forControlEvents: UIControlEvents.TouchUpInside)
        return button
    }
    
    // ボタンアクションの定義
    func onTapButton(sender: UIButton)  {
        if self.backgroundColor == UIColor.lightGrayColor() {
            self.backgroundColor = UIColor.cyanColor()
            myField.textColor = UIColor.blueColor()
        } else {
            self.backgroundColor = UIColor.lightGrayColor()
            myField.textColor = UIColor.whiteColor()
        }
    }

    override func drawRect(rect: CGRect) {
        let button = makeButton(CGRectMake(100, 200, 100, 50), title: "Change Color", tag: 0)
        let label2 = makeLabel(CGRectMake(30, 100, 70, 35), text: "Label")
        myField.frame = CGRectMake(120, 100, 150, 35)
        myField.placeholder = "Type Something"
        myField.textColor = UIColor.whiteColor()
        myField.backgroundColor = UIColor.redColor()
        
        self.addSubview(button)
        self.addSubview(label2)
        self.addSubview(myField)
    }

}

let myView = PGView(frame: CGRect(x: 0, y: 0, width: 300, height: 400))

XCPlaygroundPage.currentPage.liveView = myView
