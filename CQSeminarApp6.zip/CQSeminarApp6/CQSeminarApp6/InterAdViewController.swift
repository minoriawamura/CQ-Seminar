//
//  InterAdViewController.swift
//  CQSeminarApp6
//
//  Created by Minori Awamura on 2016/05/08.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit
import iAd

class InterAdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // 全画面広告表示
        UIViewController.prepareInterstitialAds()
        self.interstitialPresentationPolicy = ADInterstitialPresentationPolicy.Automatic
        self.requestInterstitialAdPresentation()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "interAdSceneSegue" {

            
        }
    }

}
