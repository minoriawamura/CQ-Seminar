//
//  ViewController.swift
//  CQSeminarApp6
//
//  Created by Minori Awamura on 2016/05/08.
//  Copyright © 2016年 Minori Awamura. All rights reserved.
//

import UIKit
import iAd

class ViewController: UIViewController  {

    
    @IBOutlet weak var adSelector: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 広告表示を有効にする
        self.canDisplayBannerAds = true
        adSelector.selectedSegmentIndex = 1

        UIViewController.prepareInterstitialAds()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        self.canDisplayBannerAds = true
        adSelector.selectedSegmentIndex = 1
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func interstitialAd(sender: UIButton) {
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "interAdSceneSegue" {
            let destVC = segue.destinationViewController as! InterAdViewController
            UIViewController.prepareInterstitialAds()
            destVC.interstitialPresentationPolicy = ADInterstitialPresentationPolicy.Automatic
        }
    }

    @IBAction func adSelectorChange(sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0 {
            self.canDisplayBannerAds = false
        } else {
            self.canDisplayBannerAds = true
        }
    }

    
}

